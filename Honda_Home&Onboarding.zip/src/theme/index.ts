import colors from './colors';
import dimension from './dimensions';

export {colors, dimension};
