export default {
  black: '#333333',
  red: '#ff0000',
  grey: '#656565',
  textGrey: '#5b5b5b',
  midGrey: '#555555',
  white: '#ffffff',
  main: '#73A5C6',
  primary:'#E41D2D',
  lightGrey:'#9DA7C4'

};
