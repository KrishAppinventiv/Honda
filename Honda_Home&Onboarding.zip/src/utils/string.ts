const strings = {
  hello: 'Hello',
};

export default strings;
