import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
  Image,
} from 'react-native';
import MapView, {Marker} from 'react-native-maps';
import Geolocation from 'react-native-geolocation-service';
import DropDownPicker from 'react-native-dropdown-picker';
import {colors} from '../../theme';
import {vh, vw} from '../../utils/dimension';
import {Images} from '../../assets';
import {useNavigation} from '@react-navigation/native';
import {Dealer} from './types';
const DealerSearch = () => {
  const navigation = useNavigation();

  const [states, setStates] = useState([
    {label: 'Uttar Pradesh', value: 'Uttar Pradesh'},
    {label: 'Maharashtra', value: 'Maharashtra'},
  ]);

  const citiesData = {
    'Uttar Pradesh': [
      {label: 'Noida', value: 'Noida'},
      {label: 'Lucknow', value: 'Lucknow'},
    ],
    Maharashtra: [
      {label: 'Mumbai', value: 'Mumbai'},
      {label: 'Pune', value: 'Pune'},
    ],
  };

  const pincodeData = {
    Noida: [
      {label: '201301', value: '201301'},
      {label: '201310', value: '201310'},
    ],
    Lucknow: [
      {label: '226001', value: '226001'},
      {label: '226010', value: '226010'},
    ],
  };

  const [selectedState, setSelectedState] = useState(null);
  const [selectedCity, setSelectedCity] = useState(null);
  const [selectedPincode, setSelectedPincode] = useState(null);
  const [stateOpen, setStateOpen] = useState(false);
  const [cityOpen, setCityOpen] = useState(false);
  const [pincodeOpen, setPincodeOpen] = useState(false);
  const [Button, SetButton] = useState('Direction');
  const [cityOptions, setCityOptions] = useState([]);
  const [pincodeOptions, setPincodeOptions] = useState([]);

  const [dealers, setDealers] = useState<Dealer[]>([]);
  const [region, setRegion] = useState({
    latitude: 28.6139,
    longitude: 77.209,
    latitudeDelta: 0.1,
    longitudeDelta: 0.1,
  });

  useEffect(() => {
    Geolocation.getCurrentPosition(
      position => {
        setRegion({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          latitudeDelta: 0.1,
          longitudeDelta: 0.1,
        });
      },
      error => console.log(error),
      {enableHighAccuracy: true},
    );
  }, []);

  useEffect(() => {
    if (selectedState) {
      setCityOptions(citiesData[selectedState] || []);
      setSelectedCity(null);
      setPincodeOptions([]);
      setSelectedPincode(null);
    }
  }, [selectedState]);

  // Update pincode options when city changes
  useEffect(() => {
    if (selectedCity) {
      setPincodeOptions(pincodeData[selectedCity] || []);
      setSelectedPincode(null);
    }
  }, [selectedCity]);

  const dummyDealers = [
    {
      id: '1',
      name: 'Pioneer One Honda',
      services: 'Sales, Service, Spare Parts',
      address: 'Prince Mohammad St, Jeddah',
      latitude: 28.5355,
      dealerImg: Images.dealerImg,
      longitude: 77.391,
      state: 'Uttar Pradesh',
      city: 'Noida',
      pincode: '201301',
    },
  ];

  // Filter dealers based on selected state, city, and pincode
  useEffect(() => {
    const filteredDealers = dummyDealers.filter(dealer => {
      return (
        (!selectedState || dealer.state === selectedState) &&
        (!selectedCity || dealer.city === selectedCity) &&
        (!selectedPincode || dealer.pincode === selectedPincode)
      );
    });

    setDealers(filteredDealers);
  }, [selectedState, selectedCity, selectedPincode]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Image source={Images.backarrow} style={styles.backButton} />
        </TouchableOpacity>
        <Text style={styles.headerText}>Dealers</Text>
      </View>

      <View style={styles.dropdownContainer}>
        <DropDownPicker
          multiple={false}
          open={stateOpen}
          setOpen={setStateOpen}
          value={selectedState}
          items={states}
          setValue={setSelectedState}
          placeholder="Select State"
          containerStyle={styles.dropdown}
        />
        <DropDownPicker
          multiple={false}
          open={cityOpen}
          setOpen={setCityOpen}
          value={selectedCity}
          items={cityOptions}
          setValue={setSelectedCity}
          placeholder="Select City"
          containerStyle={styles.dropdown}
          disabled={!selectedState}
        />
        <DropDownPicker
          multiple={false}
          setOpen={setPincodeOpen}
          open={pincodeOpen}
          value={selectedPincode}
          items={pincodeOptions}
          setValue={setSelectedPincode}
          placeholder="Select Pincode"
          containerStyle={styles.dropdown}
          disabled={!selectedCity}
        />
      </View>

      {/* Map */}
      <MapView style={styles.map} region={region}>
        {dealers.map(dealer => (
          <Marker
            key={dealer.id}
            coordinate={{
              latitude: dealer.latitude,
              longitude: dealer.longitude,
            }}
            title={dealer.name}
            description={dealer.services}
          />
        ))}
      </MapView>

      <FlatList
        data={dealers}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <View style={styles.dealerCard}>
            <View style={{flexDirection: 'row'}}>
              <Image
                source={Images.dealerImg}
                style={{width: vh(118), height: vh(118), borderRadius: vh(8)}}
              />
              <View>
                <Text style={styles.dealerName}>{item.name}</Text>
                <Text style={styles.dealerService}>{item.services}</Text>
                <Text style={styles.dealerAddress}>{item.address}</Text>
              </View>
            </View>
            <View style={styles.buttonRow}>
              <TouchableOpacity
                style={[
                  styles.button,
                  Button === 'Email' && styles.directionButton,
                ]}
                onPress={() => SetButton('Email')}>
                <Text
                  style={[
                    styles.buttonText,
                    Button === 'Email' && {color: colors.primary},
                  ]}>
                  Email
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.button,
                  Button === 'Call' && styles.directionButton,
                ]}
                onPress={() => SetButton('Call')}>
                <Text
                  style={[
                    styles.buttonText,
                    Button === 'Call' && {color: colors.primary},
                  ]}>
                  Call
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.button,
                  Button === 'Direction' && styles.directionButton,
                ]}
                onPress={() => SetButton('Direction')}>
                <Text
                  style={[
                    styles.buttonText,
                    Button === 'Direction' && {color: colors.primary},
                  ]}>
                  Get Direction
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </SafeAreaView>
  );
};

export default DealerSearch;

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#fff'},
  header: {flexDirection: 'row', alignItems: 'center', padding: vh(10)},
  headerText: {fontSize: vh(20), fontWeight: 'bold', marginLeft: vw(10)},
  backButton: {width: vh(24), height: vh(24), resizeMode: 'contain'},
  dropdownContainer: {flexDirection: 'row', padding: vh(10)},
  dropdown: {flex: 1, marginHorizontal: vw(5)},
  map: {height: vh(250), marginBottom: vh(10)},
  dealerCard: {
    backgroundColor: '#fff',
    padding: vh(15),
    marginVertical: vh(5),
    borderRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  dealerName: {
    fontSize: vh(18),
    fontWeight: 'bold',
    color: '#222',
    marginBottom: vh(5),
  },
  dealerService: {
    fontSize: vh(14),
    color: '#777',
    marginBottom: vh(3),
  },
  dealerAddress: {
    fontSize: vh(12),
    color: '#555',
    marginBottom: vh(8),
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: vh(16),
  },
  button: {
    backgroundColor: '#ccc',
    padding: vh(8),
    borderRadius: 5,
    width: vh(100),
    height: vh(36),
    justifyContent: 'center',
    alignItems: 'center',
  },
  directionButton: {
    borderWidth: 1,
    borderColor: colors.primary,
    padding: vh(8),
    borderRadius: 5,
    width: vh(100),
    height: vh(36),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 0, 0, 0.1)',
  },
  buttonText: {color: '#fff'},
});
