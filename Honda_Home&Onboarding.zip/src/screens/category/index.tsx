import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Category = () => {
  return (
    <View>
      <Text>index</Text>
    </View>
  )
}

export default Category

const styles = StyleSheet.create({})