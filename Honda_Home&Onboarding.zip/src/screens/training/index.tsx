import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Training = () => {
  return (
    <View>
      <Text>index</Text>
    </View>
  )
}

export default Training

const styles = StyleSheet.create({})