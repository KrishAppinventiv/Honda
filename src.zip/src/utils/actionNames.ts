export default {
  //Auth Actions
  loginAction: '',
  registerAction: '',
  deleteAccountAction: '',
  otpVerificationAction: 'authSlice/otpVerificationAction',
  resendOtpAction: 'authSlice/resendOtpAction',
  addUpdateUserCategory: 'authSlice/addUpdateUserCategory',
  companyListAction: 'authSlice/companyListAction',
  departmentListAction: 'authSlice/departmentListAction',
  positionListAction: 'authSlice/positionListAction',
  uploadProfileAction: 'authSlice/uploadProfileAction',
  UpdateDeviceTimeFormat: 'authSlice/UpdateDeviceTimeFormat',
  staticContent: 'authSlice/staticContent',
  //HOME ACTION
  //USER ACTIONS
};
