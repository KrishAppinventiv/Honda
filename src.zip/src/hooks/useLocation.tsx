import { View, Text } from 'react-native'
import React from 'react'

const useLocation = () => {
  return (
    <View>
      <Text>useLocation</Text>
    </View>
  )
}

export default useLocation
