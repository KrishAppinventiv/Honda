import {Image, ImageSourcePropType, ScrollView, Text, View} from 'react-native';
import React, {useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
// Custom Components
import CustomStatusBar from '../../components/statusBar';
import CustomHeader from '../../components/customHeader';
import {SingleExpandableList} from '../../components/customAccordian';
import Carousel from '../../components/customCorousel';
import { steps } from '../staticContent/productDetail';
import Button from '../../components/Button';
// Assets
import { Images } from '../../assets';
//Utils
import {RootStackParamList} from '../../utils/types';
//styles
import styles from './styles';
import { STRINGS } from '../../utils';
import { ScreenNames } from '../../utils/screenNames';

// Types
interface ProductDetailPageProps {
  navigation: NativeStackNavigationProp<RootStackParamList>;
}
interface Item {
  id: string;
  title: string;
  image: ImageSourcePropType;
}

// Main Component
const ProductDetailPage = ({navigation}: ProductDetailPageProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  // Function to expand the clicked item and collapse others
  const handleExpand = (index: number) => {
    if (expandedIndex === index) {
      setExpandedIndex(null);
    } else {
      setExpandedIndex(index);
    }
  };

  // Function to handle Scrolling of Corousel
  const handleScrollEnd = (event: {
    nativeEvent: {contentOffset: {x: number}};
  }) => {
    const newIndex = Math.round(
      event.nativeEvent.contentOffset.x / styles.slide.width,
    );
    setCurrentStep(newIndex);
  };

  // Corousel Render Item
  const corouselRenderItem = ({item}: {item: Item}) => (
    <View style={styles.slide}>
      <Image source={item.image} style={styles.image} />
    </View>
  );

  // Navigating back on Back Press
  const onBackPress = () => {
    navigation.goBack();
  };

  // Function to Toggle the expanded state of Description
  const toggleDescription = () => {
    setExpanded(!expanded);
  };

  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomStatusBar />
      <CustomHeader
        backButton
        backIcon={Images.back}
        onBackPress={onBackPress}
        headerStyle={styles.header}
        headerImgStyle={styles.headerImg}
      />
      <ScrollView showsVerticalScrollIndicator={false}>
        <Carousel
          data={steps}
          currentStep={currentStep}
          renderItem={corouselRenderItem}
          handleScrollEnd={handleScrollEnd}
          paginationStyle={styles.pagination}
        />
        <View style={styles.bottomContainer}>
          <View>
            <View style={styles.productDetailContainer}>
              <View>
                <Text style={styles.productName}>{'EU70is'}</Text>
              </View>
              <Text style={styles.productDetail}>
                {'Generators | Inverter Series'}
              </Text>
            </View>
            <View>
              <Text style={styles.productDescription}>
                {expanded
                  ? STRINGS.ProductDetailPage.moreDescription
                  : STRINGS.ProductDetailPage.lessDescription}
                <Text style={styles.readMore} onPress={toggleDescription}>
                  {expanded ? ' Read less' : 'Read more'}
                </Text>
              </Text>
            </View>
          </View>
          <View style={styles.allExpandableContainer}>
            <SingleExpandableList
               icon={Images.downIcon}
              title={'Specifications'}
              containerStyle={styles.singleExpandableContainer}
              isExpanded={expandedIndex === 0}
              onPress={() => handleExpand(0)}
            />
            <SingleExpandableList
               icon={Images.downIcon}
              title={'Technology'}
              containerStyle={styles.singleExpandableContainer}
              isExpanded={expandedIndex === 1}
              onPress={() => handleExpand(1)}
            />
            <SingleExpandableList
               icon={Images.downIcon}
              title={'Salient Features'}
              containerStyle={styles.singleExpandableContainer}
              isExpanded={expandedIndex === 2}
              onPress={() => handleExpand(2)}
            />
            <SingleExpandableList
              icon={Images.downIcon}
              title={'Extended Warranty of Features'}
              containerStyle={styles.singleExpandableContainer}
              isExpanded={expandedIndex === 3}
              onPress={() => handleExpand(3)}
            />
            <SingleExpandableList
               icon={Images.downIcon}
              title={'Download Content'}
              containerStyle={styles.singleExpandableContainer}
              isExpanded={expandedIndex === 4}
              onPress={() => handleExpand(4)}
            />
            <SingleExpandableList
              icon={Images.downIcon}
              title={'Popular Applications'}
              containerStyle={styles.singleExpandableContainer}
              isExpanded={expandedIndex === 5}
              onPress={() => handleExpand(5)}
            />
            <View style={styles.dealerContainer}>
              <Text style={styles.dealer}>{'Dealers'}</Text>
              <Text onPress={()=>navigation?.navigate(ScreenNames.DealerSearch)} style={styles.locateDealer}>{'Locate Dealer'}</Text>
            </View>
            <View style={styles.alertBanner}>
              <View style={styles.alertHeader}>
                <Image source={Images.infoIcon} style={styles.infoImg} />
                <Text style={styles.alertTitle}>{'Disclaimer'}</Text>
              </View>
              <View style={styles.alertDescriptionContainer}>
                <Text style={styles.alertDescription}>
                  {STRINGS.ProductDetailPage.alertDescription}
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
      <View style={styles.footer}>
        <View style={styles.footerContentContainer}>
          <View style={styles.footerTextContainer}>
            <Text style={styles.priceText}>{'₹ 245,000.00'}</Text>
            <Text style={styles.priceDetailText}>
              {'Inclusive of all taxes'}
            </Text>
          </View>
          <Button
            text={'BUY NOW'}
            onPress={() => {}}
            style={styles.buyNowButton}
            textStyle={styles.buyNowButtonText}
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

export default ProductDetailPage;
