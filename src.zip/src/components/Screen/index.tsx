import {Screen} from './Screen';

export default Screen;
