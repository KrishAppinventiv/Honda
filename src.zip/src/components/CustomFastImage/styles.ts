import { StyleSheet } from "react-native";
import { vw } from "../../styles";

const styles = StyleSheet.create({
    defaultStyle: {
        width: vw(24),
        height: vw(24),
      },
});

export default styles;