

interface CustomCardProps {
  title: string;

  isExpanded?: boolean;
  onAccordionPress?: () => void;

  expandImage?: any;
  unexpandImage?: any;
  iconSize?: number;
  iconColor?: string;
  children?:ReactNode
  
}




import React, { ReactNode } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { vh } from '../../styles';


const SingleExpandableList = ({ title, isExpanded, onAccordionPress, children ,expandImage, unexpandImage,
 iconSize,
    iconColor}:CustomCardProps) => {
  return (
    <View style={styles.container}>
      <View  style={styles.header}>
        <Text style={styles.title}>{title}</Text>
        <TouchableOpacity onPress={onAccordionPress}>
        <Image
                source={isExpanded ? expandImage : unexpandImage}
                style={[
                  styles.iconImage,
                  {
                    width: iconSize || 24,
                    height: iconSize || 24,
                    tintColor: iconColor || '#666',
                  },
                ]}
              />
      </TouchableOpacity>
      </View>
      {isExpanded && <View style={styles.content}>{children}</View>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { marginTop: vh(24) ,borderWidth:1,borderRadius:vh(12),borderColor:'#D4DAEA',justifyContent:'center'},
  header: { flexDirection: 'row', justifyContent: 'space-between', padding: 10,marginTop: 10},
  title: { fontSize: 16, fontWeight: 'bold' },
  content: { padding: 10 },
  iconImage: {
    resizeMode: 'contain',
  },
});

export default SingleExpandableList;
