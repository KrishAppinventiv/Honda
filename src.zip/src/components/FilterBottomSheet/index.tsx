import React, {useRef, useCallback, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Image,
} from 'react-native';
import BottomSheet, {BottomSheetView} from '@gorhom/bottom-sheet';
import {GestureHandlerRootView} from 'react-native-gesture-handler';
import {runOnJS} from 'react-native-reanimated';

import MultiSlider from '@ptomasroos/react-native-multi-slider';

import {Images} from '../../assets';

import CheckBox from 'react-native-check-box';
import styles from './styles';

import CustomFlatList from '../CustomFlatList';
import SingleExpandableList from '../customAccordian';
import { screenWidth } from '../../styles';
import { categoriesData, typesData } from '../../staticData';

interface FilterBottomSheetProps {
  visible: boolean;
  onClose: () => void;
  showCheckbox?: boolean;
  onApplyFilter: (priceRange: number[], selectedCategories: string[]) => void;
  onClearAll: () => void;
}

const FilterBottomSheet: React.FC<FilterBottomSheetProps> = ({
  visible,
  onClose,
  showCheckbox = true,
  onApplyFilter,
  onClearAll,
}) => {
  const bottomSheetRef = useRef<BottomSheet>(null);
  const [priceRange, setPriceRange] = useState([10000, 265000]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [categoriesExpanded, setCategoriesExpanded] = useState(false);
  // Handle BottomSheet Close
  const handleSheetChanges = useCallback(
    (index: number) => {
      if (index === -1) {
        runOnJS(onClose)();
      }
    },
    [onClose],
  );

  const toggleCategory = (category: string) => {
    setSelectedCategories(prev =>
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category],
    );
  };

  const toggleType = (type: string) => {
    setSelectedTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type],
    );
  };

  const applyFilter = () => {
    onApplyFilter(priceRange, selectedCategories);
    onClose();
  };

  if (!visible) return null;

  const priceDifference = priceRange[1] - priceRange[0];

  return (
    <GestureHandlerRootView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'android' ? 50 : 0}
        style={{flex: 1}}>
           <TouchableOpacity style={styles.closeButton} onPress={onClose}>
              <Image source={Images.close} style={styles.close}/>
            </TouchableOpacity>
        <BottomSheet
          ref={bottomSheetRef}
          index={0}
          // snapPoints={["25%", "50%", "90%"]}
          onChange={handleSheetChanges}
          enablePanDownToClose={true}
          enableContentPanningGesture={true}>
          <BottomSheetView style={styles.content}>
            {/* Close Button */}
           

            <ScrollView
              showsVerticalScrollIndicator={false}
              nestedScrollEnabled={true}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{flexGrow: 1}}>
              <View style={styles.header}>
                <Text style={styles.title}>Filter</Text>
                <TouchableOpacity onPress={onClearAll}>
                  <Text style={styles.clearText}>Clear all</Text>
                </TouchableOpacity>
              </View>

              <Text style={styles.sectionTitle}>Price Range</Text>

              <View style={styles.priceDisplay}>
                <Text style={styles.priceText}>₹ {priceDifference}</Text>
              </View>

              <MultiSlider
                values={priceRange}
                sliderLength={screenWidth - 50}
                min={0}
                max={265000}
                step={1000}
                allowOverlap={false}
                snapped
                markerStyle={styles.sliderMarker}
                selectedStyle={styles.sliderSelected}
                trackStyle={styles.sliderTrack}
                onValuesChange={values => {
                  console.log('Updated Values:', values);
                  setPriceRange(values);
                }}
              />

              <View style={styles.priceLabels}>
                <Text style={styles.textRange}>₹ {priceRange[0]}</Text>
                <Text>₹ {priceRange[1]}</Text>
              </View>

              <Text style={styles.sectionTitle}>Type</Text>
              <CustomFlatList
                data={typesData}
                keyExtractor={item => item.id}
                horizontal
                contentContainerStyle={styles.typeFlat}
                renderItem={({item}) => (
                  <TouchableOpacity
                    style={[
                      styles.typeButton,
                      selectedTypes.includes(item.label) && styles.selectedType,
                    ]}
                    onPress={() => toggleType(item.label)}>
                    <Text
                      style={[
                        styles.typeText,
                        selectedTypes.includes(item.label) &&
                          styles.selectedTypeText,
                      ]}>
                      {item.label}
                    </Text>
                  </TouchableOpacity>
                )}
              />

              <SingleExpandableList
                title="Categories"
                isExpanded={categoriesExpanded}
                onAccordionPress={() =>
                  setCategoriesExpanded(!categoriesExpanded)
                }
                expandImage={Images.expand}
                unexpandImage={Images.unexpand}
                iconColor="#050507">
                {showCheckbox && (
                  <CustomFlatList
                    data={categoriesData}
                    keyExtractor={item => item.id}
                    scrollEnabled={false}
                    renderItem={({item}) => (
                      <TouchableOpacity
                        style={styles.categoryItem}
                        onPress={() => toggleCategory(item.label)}>
                        <CheckBox
                          isChecked={selectedCategories.includes(item.label)}
                          onClick={() => toggleCategory(item.label)}
                          rightText={item.label}
                          checkBoxColor="#050507"
                        />
                        <Text style={styles.categoryText}>{item.label}</Text>
                      </TouchableOpacity>
                    )}
                  />
                )}
              </SingleExpandableList>
            </ScrollView>
          </BottomSheetView>
        </BottomSheet>
      </KeyboardAvoidingView>
      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
          <Text style={styles.cancelText}>CANCEL</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.applyButton} onPress={applyFilter}>
          <Text style={styles.applyText}>APPLY</Text>
        </TouchableOpacity>
      </View>
    </GestureHandlerRootView>
  );
};


export default FilterBottomSheet;
