import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Promotion = () => {
  return (
    <View>
      <Text>index</Text>
    </View>
  )
}

export default Promotion

const styles = StyleSheet.create({})