import { NativeStackScreenProps } from '@react-navigation/native-stack';
import React, { useState } from 'react';
import { Image, ListRenderItemInfo, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import CustomFlatList from '../../../components/CustomFlatList';
import styles from './styles';
import { Images } from '../../../assets';
import CustomHeader from '../../../components/customHeader';
import CustomStatus from '../../../components/CustomStatus';
import CustomSocialAccount from '../../../components/CustomSocialAccount';

type RootStackParamList = {
    MyProfile: undefined;
}

type DataItem = {
    id: number,
    title: string,
}

const data: DataItem[] = [
    { id: 1, title: 'Retailers' },
    { id: 2, title: 'Locate Dealer', },
    { id: 3, title: 'Price List', },
    { id: 4, title: 'Dealer Slab' },
    { id: 5, title: 'Download Content' },
    { id: 6, title: 'Settings' },
    { id: 7, title: 'Logout' }
]

type MoreScreenProps = NativeStackScreenProps<RootStackParamList, 'MyProfile'>;

const More: React.FC<MoreScreenProps> = ({ navigation }) => {
    const insets = useSafeAreaInsets();
    const [expandedItems, setExpandedItems] = useState<number | null>(null);
    const backPress = () => {
        navigation.goBack();
    }

    const toggleExpand = (id: number) => {
        setExpandedItems(prevId => (prevId === id ? null : id));
    };

    const renderItem = ({ item }: ListRenderItemInfo<DataItem>) => {
        const isExpanded = expandedItems === item.id;
        // return (
        //     <CustomCard
        //         title={item.title}
        //         description=''
        //         isExpanded={isExpanded}
        //         showAccordion={true}
        //         cardStyle={styles.firstContainer}
        //         unexpandImage={icons.right}
        //         iconColor='#E41D2D'
        //         iconSize={12}
        //         onAccordionPress={() => toggleExpand(item.id)}
        //         titleStyle={styles.text}
        //     />
        // )
    }

    return (
        <View style={[styles.container, { paddingTop: insets.top }]}>
            <CustomStatus />
            <CustomHeader onleftPress={backPress} leftIcon={Images.backarrow} leftButton rightButton leftIconStyle={styles.image} headerStyle={styles.header} rightIcon={Images.bellIcon} rightButtonStyle={{ backgroundColor: '#F4F7FF', }} />
            <View style={styles.cardContainer}>
                <Image source={Images.moreFlatlist} style={styles.imageHii} resizeMode='contain' />
                <View style={styles.hiValueContainer}>
                    <Text style={styles.title1}>Jenny Honda</Text>
                    <View style={styles.phoneContainer}>
                        <Image source={Images.phone} style={styles.phone} resizeMode='contain' />
                        <Text style={styles.description1}>+91-9878767656</Text>
                    </View>
                    <TouchableOpacity style={styles.viewContainer}>
                        <Text style={styles.viewText}>View Profile</Text>
                        <Image source={Images.right} style={styles.arrow} resizeMode='contain' />
                    </TouchableOpacity>
                </View>
            </View>
            <View>
                <CustomFlatList
                    data={data}
                    renderItem={renderItem}
                    keyExtractor={(item) => item.id}
                    horizontal={false}
                    showsVerticalScrollIndicator={false}
                />
            </View>
            <CustomSocialAccount />
        </View>
    )
}

export default More