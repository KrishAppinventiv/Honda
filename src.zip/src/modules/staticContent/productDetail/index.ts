export const steps = [
    {
      key: '1',
      title: 'Lorem ipsum dolor sit amet, consectetur adipiscing',
      description:
        'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
      image: require('../../../assets/images/tutorial1.png'),
    },
    {
      key: '2',
  
      title: 'Lorem ipsum dolor sit amet, consectetur adipiscing',
      description:
        'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
      image: require('../../../assets/images/tutorial2.png'),
    },
    {
      key: '3',
  
      title: 'Lorem ipsum dolor sit amet, consectetur adipiscing',
      description:
        'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
      image: require('../../../assets/images/tutorial3.png'),
    },
  ];
  
  
  export const specifications = [
    {
      id: '1',
      feature: 'Air Cleaner',
      value: 'Dual type',
    },
    {
      id: '2',
      feature: 'Bore X Stroke (mm)',
      value: '88 x 64',
    },
    {
      id: '3',
      feature: 'Compression ratio',
      value: '8.2:1',
    },
    {
      id: '4',
      feature: 'Displacement (cm3)',
      value: '389',
    },
    {
      id: '5',
      feature: 'Fuel Tank Capacity (L)',
      value: '19.2',
    },
    {
      id: '6',
      feature: 'Fuel Type',
      value: 'Unleaded gasoline',
    },
  ];