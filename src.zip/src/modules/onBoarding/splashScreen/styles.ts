import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  container: {
   resizeMode:'contain'
  },
  containers: {
    flex: 1,
    justifyContent:'center',
    alignItems:'center'

  },
  flex_1: {
    flex: 1,
    
  },
  imageStyle: {
    
    marginHorizontal:20, 
  },
});
