/* eslint-disable react/no-unstable-nested-components */
import {
  Image,
  ImageSourcePropType,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

import {RootStackParamList} from '../../utils/types';

import GlobalHeader from '../../components/GlobalHeader';
import {Images} from '../../assets';


import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import CustomFlatList from '../../components/CustomFlatList';
import CustomButton from '../../components/CustomButton';
import FilterBottomSheet from '../../components/FilterBottomSheet';
import styles from './styles';
import { newArrivals } from '../../staticData';
import CustomSearch from '../../components/CustomSearchBar';


interface NewArrivalsProps {
  navigation: NativeStackNavigationProp<RootStackParamList>;
}

interface Item {
  id: string;
  title: string;
  image: ImageSourcePropType;
  number: string;
  price: string;
}

const NewArrivals = ({navigation}: NewArrivalsProps) => {
  const [searchText, setSearchText] = useState('');
  const [isFilterVisible, setFilterVisible] = useState(false);
  const [priceRange, setPriceRange] = useState([10000, 265000]); 
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]); 
  const [resetFilter, setResetFilter] = useState(true); 

  const toggleFilter = () => {
    setFilterVisible(!isFilterVisible);
  };

  
  const filteredData = newArrivals.filter(item => {
    // Extract numeric price from the string
    const price = parseFloat(item.price.replace(/[₹,]/g, '').trim());
    const isInPriceRange = price >= priceRange[0] && price <= priceRange[1];

   
    const isInSelectedCategories =
      selectedCategories.length === 0 ||
      selectedCategories.includes(item.title);

    console.log(
      `Item: ${item.title}, Price: ${price}, In Price Range: ${isInPriceRange}, In Selected Categories: ${isInSelectedCategories}`,
    );

    return isInPriceRange && isInSelectedCategories; 
  });

 
  const dataToShow = resetFilter ? newArrivals : filteredData;

  const GeneratorsRenderItem = ({item}: {item: Item}) => (
    <TouchableOpacity
      style={styles.textHeaderItemContainer}
      activeOpacity={0.5}
      onPress={() => {}}>
      <View style={styles.textHeaderImageContainer}>
        <Image source={item.image} style={styles.textHeaderItemImage} />
      </View>
      <View>
        <Text style={styles.textHeaderItemNumber}>{item.number}</Text>
        <Text style={styles.textHeaderItemTitle}>{item.title}</Text>
        <Text style={styles.textHeaderItemPrice}>{item.price}</Text>
      </View>
    </TouchableOpacity>
  );
  const handleSearchPress = () => {};
  return (
    <SafeAreaView style={styles.mainContainer}>
      <GlobalHeader
        headerStyle={styles.header}
        leftButton
        rightButton
        leftIcon={Images.back}
        textHeading="New Arrivals"
        leftButtonStyle={styles.backButton}
        onleftPress={navigation.goBack}
      />
      <CustomFlatList
        data={dataToShow}
        renderItem={GeneratorsRenderItem}
        keyExtractor={item => item.id}
        horizontal={false}
        numColumns={2}
        contentContainerStyle={styles.customFlatListStyle}
        listHeaderComponent={
          <>
            <CustomSearch
              placeholder="Search Product"
              style={styles.searchContainer}
              value={searchText}
              onChangeText={text => setSearchText(text)}
              onPress={handleSearchPress}
            />
          </>
        }
      />
      <View style={styles.footer}>
        {!isFilterVisible && (
          <View style={styles.footerContentContainer}>
            <CustomButton
              buttonText={'Sort By'}
              iconSource={Images.sort}
              iconStyle={styles.sortByIcon}
              onPress={() => {}}
              buttonStyle={styles.sortByButton}
              textStyle={styles.sortByButtonText}
            />
            <CustomButton
              buttonText={'Filter'}
              iconSource={Images.filter}
              iconStyle={styles.filterIcon}
              onPress={toggleFilter}
              buttonStyle={styles.filterButton}
              textStyle={styles.filterButtonText}
            />
          </View>
        )}
      </View>

      <FilterBottomSheet
        visible={isFilterVisible}
        onClose={toggleFilter}
        onApplyFilter={(selectedPriceRange, selectedCategories) => {
          setPriceRange(selectedPriceRange);
          setSelectedCategories(selectedCategories);
          setFilterVisible(false);
          setResetFilter(false); 
        }}
        onClearAll={() => {
          setResetFilter(true); 
          setFilterVisible(false);
        }}
      />
    </SafeAreaView>
  );
};

export default NewArrivals;

