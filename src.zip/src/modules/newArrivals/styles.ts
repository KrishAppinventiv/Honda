import {StyleSheet} from 'react-native';


import { ROBOTO_BOLD, ROBOTO_MEDIUM, ROBOTO_REGULAR } from '../../styles/Fonts';
import colors from '../../utils/colors';
import { normalize, vh, vw } from '../../styles';

export default StyleSheet.create({
    mainContainer: {
        flex: 1,
        backgroundColor: colors.white,
      },
      header: {
        paddingVertical: vh(14),
        paddingHorizontal:vh(16),
        borderBottomWidth: 1,
        borderBottomColor: '#00000012',
        shadowColor: '#00000012',
        shadowOffset: {width: 0, height: 1},
        shadowOpacity: 0.9,
        shadowRadius: 14,
        elevation: 3,
      },
      backButton: {
        backgroundColor: '#F4F7FF',
      },
      searchContainer: {
        marginHorizontal: vw(8),
        marginBottom: vh(4),
      },
      customFlatListStyle: {
        paddingHorizontal: vw(8),
        paddingBottom: vh(10),
      },
      textHeaderItemContainer: {
        width: vw(182),
        height: vw(215),
        backgroundColor: colors.white,
        borderRadius: 12,
        marginHorizontal: vw(8),
        marginVertical: vh(12),
      },
      textHeaderImageContainer: {
        width: vw(182),
        height: vw(136),
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 12,
        backgroundColor: '#F3F6FA',
      },
      textHeaderItemImage: {
        width: vw(100),
        height: vw(100),
        alignSelf: 'center',
        resizeMode: 'contain',
      },
      textHeaderItemNumber: {
        fontSize: normalize(16),
        fontFamily: ROBOTO_BOLD,
        fontWeight: '700',
        marginTop: vh(10),
      },
      textHeaderItemTitle: {
        fontSize: normalize(14),
        fontFamily: ROBOTO_REGULAR,
        fontWeight: '400',
        marginTop: vh(8),
        color: '#7C8585',
      },
      textHeaderItemPrice: {
        fontSize: normalize(14),
        fontFamily: ROBOTO_BOLD,
        fontWeight: '600',
        marginTop: vh(8),
        color: colors.black,
      },
      footer: {
        width: '100%',
        backgroundColor: colors.white,
        shadowColor: '#DCE3ED99',
        shadowOffset: {width: 0, height: -4},
        shadowOpacity: 0.9,
        shadowRadius: 40,
        elevation: 10,
        borderTopWidth: 1,
        borderTopColor: colors.border,
      },
      footerContentContainer: {
        backgroundColor: colors.white,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: vh(14),
      },
      sortByButton: {
        flexDirection: 'row',
        width: vw(206),
        height: vw(36),
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: colors.white,
        borderRightWidth: 0.5,
        borderRightColor: colors.border,
      },
      sortByIcon: {
        width: vw(24),
        height: vw(24),
        resizeMode: 'contain',
      },
      sortByButtonText: {
        fontSize: normalize(18),
        fontFamily: ROBOTO_MEDIUM,
        fontWeight: '500',
        marginLeft: vw(12),
        color: colors.black,
      },
      filterButton: {
        flexDirection: 'row',
        width: vw(206),
        height: vw(36),
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: colors.white,
        borderLeftWidth: 0.5,
        borderLeftColor: colors.border,
      },
      filterIcon: {
        width: vw(24),
        height: vw(24),
        resizeMode: 'contain',
      },
      filterButtonText: {
        fontSize: normalize(16),
        fontFamily: ROBOTO_MEDIUM,
        fontWeight: '500',
        marginLeft: vw(12),
        color: colors.black,
      },
})