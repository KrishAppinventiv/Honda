interface BannerItem {
    img: any;
    text: string;
    head: string;
  }