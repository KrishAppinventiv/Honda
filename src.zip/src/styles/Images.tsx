const Images = {
  splashLogo: require('../assets/images/hondaPower.png'),
  onboarding: require('../assets/images/handshake.png'),
  onboarding1: require('../assets/images/handshake.png'),
  onboarding2: require('../assets/images/handshake.png'),
  onboarding3: require('../assets/images/handshake.png'),
  onBoardingTwo: require('../assets/images/handshake.png'),
  image_onboarding: require('../assets/images/handshake.png'),
  // splashLogoGif: require('../assets/images/.gif'),
  
  //Login Screen
  
  //OTP VERIFICATION SCREEN
};
export default Images;
